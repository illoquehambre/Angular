export const environment = {
  production: true,
  API_BASE_URL: 'https://api.themoviedb.org/3/',
  api_key: '0853d96c8c16b6010ba4b1256519fa3e'
};
